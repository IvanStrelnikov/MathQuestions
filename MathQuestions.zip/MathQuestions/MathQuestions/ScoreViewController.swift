//
//  ScoreViewController.swift
//  MathQuestions
//
//  Created by mac on 12.06.2020.
//  Copyright © 2020 IvanStrelnikov. All rights reserved.
//

import UIKit

class ScoreViewController: UIViewController {

    @IBOutlet weak var userScoreLabel: UILabel!
    @IBOutlet weak var antonScoreLabel: UILabel!
    @IBOutlet weak var egorScoreLabel: UILabel!
    @IBOutlet weak var torinScoreLabel: UILabel!
    @IBOutlet weak var legolasScoreLabel: UILabel!
    
    var userScore: Int?
    var antonScore = Int()
    var egorScore = Int()
    var torinScore = Int()
    var legolasScore = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        printTotalScore()
    }
    
    func printTotalScore() {
        antonScore = Int(arc4random_uniform(UInt32(14)))
        egorScore = Int(arc4random_uniform(UInt32(14)))
        torinScore = Int(arc4random_uniform(UInt32(14)))
        legolasScore = Int(arc4random_uniform(UInt32(14)))
        
        guard let scoreUser = self.userScore else { return }
        
        userScoreLabel.text = "Your score: \(scoreUser)"
        antonScoreLabel.text = "Anton score: \(antonScore)"
        egorScoreLabel.text = "Egor score: \(egorScore)"
        torinScoreLabel.text = "Torin score: \(torinScore)"
        legolasScoreLabel.text = "Legolas score: \(legolasScore)"
        
    }
    
    @IBAction func playAgainButton(_ sender: UIButton) {
    }
}
