//
//  ViewController.swift
//  MathQuestions
//
//  Created by mac on 12.06.2020.
//  Copyright © 2020 IvanStrelnikov. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var question: UILabel!
    @IBOutlet var ansField: UITextField!
    
    var scoreMath = Int(0)
    var answer = Double()
    var num1 = Double()
    var num2 = Double()
    var sign = String()
    var signNum = Int()
    var countProblem = Int(15)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        num1 = Double(arc4random_uniform(UInt32(500)))
        num2 = Double(arc4random_uniform(UInt32(500)))
        signNum = Int(arc4random_uniform(UInt32(2)))
        
        switch signNum {
        case 0:
            sign = "+"
            answer = num1 + num2
            break
        case 1:
            sign = "-"
            answer = num1 - num2
            break
        case 2:
            sign = "x"
            answer = num1 * num2
            break
        case 3:
            sign = "/"
            answer = num1 / num2
            break
        case 4:
            sign = "^2"
            answer = pow(num1, num2)
            break
        default:
            break
        }
        
        question.text = "\(num1)\(sign)\(num2) = "
        ansField.text = ""
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let dvc = segue.destination as? ScoreViewController else { return }
        
        dvc.userScore = scoreMath
    }
    
     @IBAction func submit(_ sender: AnyObject) {
        
        num1 = Double(arc4random_uniform(UInt32(500)))
        num2 = Double(arc4random_uniform(UInt32(500)))
        signNum = Int(arc4random_uniform(UInt32(2)))
        
        switch signNum {
        case 0:
            sign = "+"
            answer = num1 + num2
            break
        case 1:
            sign = "-"
            answer = num1 - num2
            break
        case 2:
            sign = "x"
            answer = num1 * num2
            break
        case 3:
            sign = "/"
            answer = num1 / num2
            break
        case 4:
            sign = "^2"
            answer = pow(num1, num2)
            break
        default:
            break
        }
        
        question.text = "\(num1)\(sign)\(num2) = "
        ansField.text = ""
     
        if Double(ansField.text!) == answer {
            scoreMath = scoreMath + 1
        } else {
            scoreMath = scoreMath - 1
        }
        problemSwitch()
     }
    
    @objc func problemSwitch() {
        countProblem -= 1
        
        if countProblem > 1 {
            viewDidLoad()
        } else if countProblem == 0 {
            performSegue(withIdentifier: "scoreSegue", sender: nil)
        }
    }
}

